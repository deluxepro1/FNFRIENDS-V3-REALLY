function onCreate()
addLuaScript('scripts extras/Glitchy icon') 

makeLuaSprite('BF', 'icons/healthicon/icon-bf', -720, -720)
scaleObject('BF', 1, 1);
setProperty('BF.flipX', true)
setObjectCamera('BF', 'hud')

makeLuaSprite('BFL', 'icons/healthicon/icon-bf2', -720, -720)
scaleObject('BFL', 1, 1);
setProperty('BFL.flipX', true)
setObjectCamera('BFL', 'hud')

makeLuaSprite('DRW', 'icons/healthicon/icon-darwin', -720, -720)
scaleObject('DRW', 1, 1);
setProperty('DRW.flipX', true)
setObjectCamera('DRW', 'hud')

makeLuaSprite('DRWL', 'icons/healthicon/icon-darwin2', -720, -720)
scaleObject('DRWL', 1, 1);
setProperty('DRWL.flipX', true)
setObjectCamera('DRWL', 'hud')

makeLuaSprite('OPPO', 'icons/healthicon/icon-gumball', -720, -720)
scaleObject('OPPO', 1, 1);
setObjectCamera('OPPO', 'hud')

makeLuaSprite('OPP', 'icons/healthicon/icon-gumball2', -720, -720)
scaleObject('OPP', 1, 1);
setObjectCamera('OPP', 'hud')

	
addLuaSprite('BF', true)
addLuaSprite('BFL', true)
addLuaSprite('DRW', true)
addLuaSprite('DRWL', true)
addLuaSprite('OPPO', true)
addLuaSprite('OPP', true)

setProperty('BF.visible', false);
setProperty('BFL.visible', false);
setProperty('DRW.visible', false);
setProperty('DRWL.visible', false);
end

function onCreatePost()
setProperty('healthBar.visible', false);
setProperty('healthBarBG.visible', false);
setProperty('iconP1.visible', false);
setProperty('iconP2.visible', false);
    
    setObjectOrder('BF', 5)
    setObjectOrder('BFL', 6)
    setObjectOrder('DRW', 7)
    setObjectOrder('DRWL', 8)
    setObjectOrder('OPPO', 9)
    setObjectOrder('OPP', 10)
	setObjectOrder('healthBar', 3)
	setObjectOrder('healthBarBG', 2)
	
if songName == 'Forgotten World' then
bf=false
darwin=true
else
bf=true
darwin=false
end

end

function onUpdate(elapsed)
setProperty('OPPO.x', getProperty('healthBar.x') + 170)
setProperty('OPPO.y', getProperty('healthBar.y') - 90)
setProperty('OPP.x', getProperty('healthBar.x') + 170)
setProperty('OPP.y', getProperty('healthBar.y') - 90)
setProperty('BF.x', getProperty('healthBar.x') + 250)
setProperty('BF.y', getProperty('healthBar.y') - 80)
setProperty('BFL.x', getProperty('healthBar.x') + 250)
setProperty('BFL.y', getProperty('healthBar.y') - 80)
setProperty('DRW.x', getProperty('healthBar.x') + 250)
setProperty('DRW.y', getProperty('healthBar.y') - 80)
setProperty('DRWL.x', getProperty('healthBar.x') + 250)
setProperty('DRWL.y', getProperty('healthBar.y') - 80)


if getProperty('health') >= 1.850 then
setProperty('OPPO.visible', false);
setProperty('OPP.visible', true);
else
setProperty('OPP.visible', false);
setProperty('OPPO.visible', true);
end

if getProperty('health') >= 0.05 then
if bf then
setProperty('BF.visible', true);
setProperty('BFL.visible', false);
end
if darwin then
setProperty('DRW.visible', true);
setProperty('DRWL.visible', false);
end
else
if bf then
setProperty('BF.visible', false);
setProperty('BFL.visible', true);
end
if darwin then
setProperty('DRW.visible', false);
setProperty('DRWL.visible', true);
end
end
end