function onEvent(name, value1, value2)
	
	
	noteTweenAngle('E',0 , value2 , value1, linear);
	noteTweenAngle('F',1 , value2 , value1, linear);
	noteTweenAngle('G',2 , value2 , value1, linear);
	noteTweenAngle('H',3 , value2 , value1, linear);
	noteTweenAngle('A',4 , value2 , value1, linear);
	noteTweenAngle('B',5 , value2 , value1, linear);
	noteTweenAngle('C',6 , value2 , value1, linear);
	noteTweenAngle('D',7 , value2 , value1, linear);
	noteTweenAngle('I',8 , value2 , value1, linear);
	noteTweenAngle('J',9 , value2 , value1, linear);
	noteTweenAngle('K',10 , value2 , value1, linear);
	noteTweenAngle('L',11 , value2 , value1, linear);
	noteTweenAngle('M',12 , value2 , value1, linear);
	noteTweenAngle('N',13 , value2 , value1, linear);
	noteTweenAngle('O',14 , value2 , value1, linear);
	noteTweenAngle('P',15 , value2 , value1, linear);
	noteTweenAngle('Q',16 , value2 , value1, linear);
	noteTweenAngle('R',17 , value2 , value1, linear);
	
end