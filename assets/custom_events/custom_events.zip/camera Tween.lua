function onEvent(name, new, time)
	if name == 'camera Tween' then
		old = getProperty('camGame.zoom')
		doTweenZoom('camGame', 'camGame', new, time, 'smootherStepInOut')
	end
end

function onTweenCompleted(tag)
	if tag == 'camGame' then
		doTweenZoom('camGame', 'camGame', old, time, 'smootherStepInOut')
	end
end