﻿function opponentNoteHit()
cameraShake('hud', 0.007, 0.5)
cameraShake('game', 0.0075, 0.5)
end