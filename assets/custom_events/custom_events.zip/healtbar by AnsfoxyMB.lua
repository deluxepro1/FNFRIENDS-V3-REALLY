function onCreate()
addLuaScript('scripts extras/Glitchy icon') 
makeAnimatedLuaSprite('uglyHB','healthbar/iconbar',0,0);
scaleObject('uglyHB', 2, 2);
doTweenX('uglyHBX', 'uglyHB.scale', 2, 0.001, 'linear')
doTweenY('uglyHBY', 'uglyHB.scale', 2, 0.001, 'linear')
luaSpriteAddAnimationByPrefix('uglyHB', 'pouco', 'Icons Bar 3', 24, true);
luaSpriteAddAnimationByPrefix('uglyHB', 'medio', 'Icons Bar 2', 24, true);
luaSpriteAddAnimationByPrefix('uglyHB', 'cheio', 'Icons Bar 1', 24, true);
luaSpritePlayAnimation('uglyHB', 'medio', true);
setObjectCamera('uglyHB', 'hud')
setScrollFactor('uglyHB', 0.9, 0.9)

if dadName == 'finn-R' then
makeLuaSprite('OPPO', 'icons/healthicon/icon-finn', -720, -720)
makeLuaSprite('OPP', 'icons/healthicon/icon-finn2', -720, -720)
end

if dadName == 'finn-sword' then
makeLuaSprite('OPPO', 'icons/healthicon/icon-finn', -720, -720)
makeLuaSprite('OPP', 'icons/healthicon/icon-finn2', -720, -720)
end

if dadName == 'jake' then
makeLuaSprite('OPPO', 'icons/healthicon/icon-jake', -720, -720)
makeLuaSprite('OPP', 'icons/healthicon/icon-jake2', -720, -720)
end

makeLuaSprite('BF', 'icons/healthicon/icon-bf', -720, -720)
scaleObject('BF', 1, 1);
setProperty('BF.flipX', true)
setObjectCamera('BF', 'hud')

makeLuaSprite('BFL', 'icons/healthicon/icon-bf2', -720, -720)
scaleObject('BFL', 1, 1);
setProperty('BFL.flipX', true)
setObjectCamera('BFL', 'hud')

makeLuaSprite('PBY', 'icons/healthicon/icon-pibby', -720, -720)
scaleObject('PBY', 1, 1);
setProperty('PBY.flipX', true)
setObjectCamera('PBY', 'hud')

makeLuaSprite('PBYL', 'icons/healthicon/icon-pibby2', -720, -720)
scaleObject('PBYL', 1, 1);
setProperty('PBYL.flipX', true)
setObjectCamera('PBYL', 'hud')

makeLuaSprite('PBY2', 'icons/healthicon/icon-pibby', -720, -720)
scaleObject('PBY2', 1, 1);
setProperty('PBY2.flipX', true)
setObjectCamera('PBY2', 'hud')

makeLuaSprite('PBYL2', 'icons/healthicon/icon-pibby2', -720, -720)
scaleObject('PBYL2', 1, 1);
setProperty('PBYL2.flipX', true)
setObjectCamera('PBYL2', 'hud')

scaleObject('OPPO', 1, 1);
setObjectCamera('OPPO', 'hud')

scaleObject('OPP', 1, 1);
setObjectCamera('OPP', 'hud')

makeLuaSprite('OPPO2', 'icons/healthicon/icon-jake', -720, -720)
scaleObject('OPPO2', 1, 1);
setObjectCamera('OPPO2', 'hud')

makeLuaSprite('OPP2', 'icons/healthicon/icon-jake2', -720, -720)
scaleObject('OPP2', 1, 1);
setObjectCamera('OPP2', 'hud')
	
addLuaSprite('uglyHB', true)
addLuaSprite('BF', true)
addLuaSprite('BFL', true)
addLuaSprite('PBY', true)
addLuaSprite('PBYL', true)
addLuaSprite('PBY2', true)
addLuaSprite('PBYL2', true)
addLuaSprite('OPPO', true)
addLuaSprite('OPP', true)
addLuaSprite('OPPO2', true)
addLuaSprite('OPP2', true)

setProperty('BF.visible', false);
setProperty('BFL.visible', false);
setProperty('PBY.visible', false);
setProperty('PBYL.visible', false);
setProperty('PBY2.visible', false);
setProperty('PBYL2.visible', false);
setProperty('OPPO2.visible', false);
setProperty('OPP2.visible', false);

if songName == 'Suffering Siblings' then
addLuaScript('scripts extras/Glitchy icon2') 
jake2=true
pibby2=true
end

end

function onCreatePost()
setProperty('healthBar.visible', false);
setProperty('healthBarBG.visible', false);
setProperty('iconP1.visible', false);
setProperty('iconP2.visible', false);
    
    setProperty('uglyHB.alpha',  getPropertyFromClass('ClientPrefs', 'healthBarAlpha'))
    setProperty('uglyHB.x', getProperty('healthBar.x') - 155)
    setProperty('uglyHB.angle', getProperty('healthBar.angle'))
    setProperty('uglyHB.y', getProperty('healthBar.y')  - 90)
    setProperty('uglyHB.scale.x', getProperty('healthBar.scale.x'))
    setProperty('uglyHB.scale.y', getProperty('healthBar.scale.y'))
    setObjectOrder('uglyHB', 4)
    setObjectOrder('BF', 5)
    setObjectOrder('BFL', 6)
    setObjectOrder('PBY', 7)
    setObjectOrder('PBYL', 8)
    setObjectOrder('OPPO', 9)
    setObjectOrder('OPP', 10)
    setObjectOrder('OPPO2', 11)
    setObjectOrder('OPP2', 12)
    setObjectOrder('PBY2', 13)
    setObjectOrder('PBYL2', 14)
	setObjectOrder('healthBar', 3)
	setObjectOrder('healthBarBG', 2)

if songName == 'Blessed by Swords' then
bf=false
pibby=true
else
bf=true
pibby=false
end

end

function onUpdate(elapsed)
setProperty('OPPO.x', getProperty('healthBar.x') + 170)
setProperty('OPPO.y', getProperty('healthBar.y') - 90)
setProperty('OPP.x', getProperty('healthBar.x') + 170)
setProperty('OPP.y', getProperty('healthBar.y') - 90)
setProperty('OPPO2.x', getProperty('healthBar.x') -170)
setProperty('OPPO2.y', getProperty('healthBar.y') - 90)
setProperty('OPP2.x', getProperty('healthBar.x') - 170)
setProperty('OPP2.y', getProperty('healthBar.y') - 90)
setProperty('BF.x', getProperty('healthBar.x') + 250)
setProperty('BF.y', getProperty('healthBar.y') - 80)
setProperty('BFL.x', getProperty('healthBar.x') + 250)
setProperty('BFL.y', getProperty('healthBar.y') - 80)
setProperty('PBY.x', getProperty('healthBar.x') + 250)
setProperty('PBY.y', getProperty('healthBar.y') - 80)
setProperty('PBYL.x', getProperty('healthBar.x') + 250)
setProperty('PBYL.y', getProperty('healthBar.y') - 80)
setProperty('PBY2.x', getProperty('healthBar.x') + 600)
setProperty('PBY2.y', getProperty('healthBar.y') - 80)
setProperty('PBYL2.x', getProperty('healthBar.x') + 600)
setProperty('PBYL2.y', getProperty('healthBar.y') - 80)

if getProperty('health') >= 1.850 then
setProperty('OPPO.visible', false);
setProperty('OPP.visible', true);

if jake2 then
setProperty('OPPO2.visible', false);
setProperty('OPP2.visible', true);
end
else
setProperty('OPP.visible', false);
setProperty('OPPO.visible', true);

if jake2 then
setProperty('OPPO2.visible', true);
setProperty('OPP2.visible', false);
end
end

if getProperty('health') >= 1.800 then
cheio=true
else
cheio=false
end

if getProperty('health') >= 1 then
medio=true
else
medio=false
end

if getProperty('health') >= 0.20 then
pouco=true
else
pouco=false
end

if getProperty('health') >= 0.05 then
if bf then
setProperty('BF.visible', true);
setProperty('BFL.visible', false);
end
if pibby then
setProperty('PBY.visible', true);
setProperty('PBYL.visible', false);
end

if pibby2 then
setProperty('PBY2.visible', true);
setProperty('PBYL2.visible', false);
end
else

if bf then
setProperty('BF.visible', false);
setProperty('BFL.visible', true);
end
if pibby then
setProperty('PBY.visible', false);
setProperty('PBYL.visible', true);
end

if pibby2 then
setProperty('PBY2.visible', false);
setProperty('PBYL2.visible', true);
end

end
end

function onBeatHit()
if cheio then 
luaSpritePlayAnimation('uglyHB', 'cheio', true);
elseif medio then
luaSpritePlayAnimation('uglyHB', 'medio', true);
elseif pouco then
luaSpritePlayAnimation('uglyHB', 'pouco', true);
end
end
